<h1> Listar Clientes </h1>

<table width="100%">
	<tr>
     <td> ID </td>
     <td> NOME  </td>
      <td>  REGISTRO </td>

	</tr>
<?php   foreach ($clientes as  $value) {?>
 	<tr>
     <td> <?php echo $value->id;?> </td>
     <td> <?php echo $value->nome;?> </td>
     <td> <?php echo $value->registro;?> </td>
     
	</tr>

<?php }?>
  
</table>



