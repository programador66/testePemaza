<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Http\Controllers\DB;
use Illuminate\Support\Facades\DB;
use App\Cliente;
class ClientesController extends Controller
{
    
       public function listar(){
       //	$clientes = DB::select('select * from clientes');
         $clientes = Cliente::all();  // comando para listar com a biblioteca orm
        return view('listar')->with('clientes',$clientes);
       	      	
       }

    public function cadastro(){
        return view('cadastro');
       	      	
       }

   

}
