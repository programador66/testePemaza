<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        $this->call('clientesTableSeeder');
    }
}


class clientesTableSeeder extends Seeder{
         public function run(){

            DB::insert('INSERT INTO clientes(codigo, nome,registro) VALUES (?, ?,?)', 
    		array('1', 'Caio Cesar','ativo'));
            DB::insert('INSERT INTO clientes (codigo, nome,registro) VALUES (?, ?,?)', 
    		array('2', 'Suzana Lacerda','ativo'));


         } 

    	
    	

}
    
    
       
    